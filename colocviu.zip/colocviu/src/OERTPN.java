package src;

import Components.*;
import DataObjects.DataFloat;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

import java.util.ArrayList;

public class OERTPN {

    public static void main(String[] args) {
        PetriNet npm = new PetriNet();
        npm.PetriNetName = "Retea";
        npm.NetworkPort = 0;

        DataFloat p0 = new DataFloat();
        p0.SetName("p0");
        p0.SetValue(1.0f);
        npm.PlaceList.add((p0));

        DataFloat p1 = new DataFloat();
        p1.SetName("p1");
        p1.SetValue(1.0f);
        npm.PlaceList.add(p1);

        DataFloat p2 = new DataFloat();
        p2.SetName("p2");
        npm.PlaceList.add(p2);

        DataFloat p3 = new DataFloat();
        p3.SetName("p3");
        p3.SetValue(1.0f);
        npm.PlaceList.add(p3);

        DataFloat p4 = new DataFloat();
        p4.SetName("p4");
        p4.SetValue(1.0f);
        npm.PlaceList.add(p4);

        DataFloat p5 = new DataFloat();
        p5.SetName("p5");
        p5.SetValue(1.0f);
        npm.PlaceList.add(p5);

        DataFloat p6 = new DataFloat();
        p6.SetName("p6");
        p6.SetValue(1.0f);
        npm.PlaceList.add(p6);

        DataFloat p7 = new DataFloat();
        p7.SetName("p7");
        npm.PlaceList.add(p7);


        //T0
        PetriTransition t0 = new PetriTransition(npm);
        t0.TransitionName = "t0";
        t0.InputPlaceName.add("p0");
        t0.InputPlaceName.add("p3");
        t0.InputPlaceName.add("p4");
        t0.InputPlaceName.add("p5");
        t0.InputPlaceName.add("p6");

        Condition c1GrdT0 = new Condition(t0, "p0", TransitionCondition.NotNull);
        Condition c2GrdT0 = new Condition(t0, "p3", TransitionCondition.NotNull);
        Condition c3GrdT0 = new Condition(t0, "p4", TransitionCondition.NotNull);
        Condition c4GrdT0 = new Condition(t0, "p5", TransitionCondition.NotNull);
        Condition c5GrdT0 = new Condition(t0, "p6", TransitionCondition.NotNull);

        c1GrdT0.SetNextCondition(LogicConnector.AND, c2GrdT0);
        c1GrdT0.SetNextCondition(LogicConnector.AND, c3GrdT0);
        c1GrdT0.SetNextCondition(LogicConnector.AND, c4GrdT0);
        c1GrdT0.SetNextCondition(LogicConnector.AND, c5GrdT0);

        GuardMapping grdT0 = new GuardMapping();
        grdT0.condition = c1GrdT0;

        ArrayList<String> lstInput = new ArrayList<String>();
        lstInput.add("p0");
        lstInput.add("p3");
        lstInput.add("p4");
        lstInput.add("p5");
        lstInput.add("p6");

        grdT0.Activations.add(new Activation(t0, lstInput, TransitionOperation.Add, "p1"));

        t0.GuardMappingList.add(grdT0);
        t0.Delay = 1;

        npm.Transitions.add(t0);


        //T1
        PetriTransition t1 = new PetriTransition(npm);
        t1.TransitionName = "t1";
        t1.InputPlaceName.add("p1");

        Condition cT2 = new Condition(t1, "p1", TransitionCondition.NotNull);

        GuardMapping guardMapping = new GuardMapping();
        guardMapping.condition = cT2;
        guardMapping.Activations.add(new Activation(t1, "p1", TransitionOperation.Move, "p2"));
        guardMapping.Activations.add(new Activation(t1, "p1", TransitionOperation.Move, "p7"));

        t1.GuardMappingList.add(guardMapping);
        t1.Delay = 1;

        npm.Transitions.add(t1);

        //T2
        PetriTransition t2 = new PetriTransition(npm);
        t2.TransitionName = "t2";
        t2.InputPlaceName.add("p2");
        Condition cT3 = new Condition(t2, "p2", TransitionCondition.NotNull);

        GuardMapping grdT3 = new GuardMapping();
        grdT3.condition = cT3;
        grdT3.Activations.add(new Activation(t2, "p2", TransitionOperation.Move, "p3"));

        t2.GuardMappingList.add(grdT3);
        t2.Delay = 1;

        npm.Transitions.add(t2);

        PetriNetWindow frame = new PetriNetWindow(false);
        frame.petriNet = npm;
        frame.setVisible(true);
    }
}
